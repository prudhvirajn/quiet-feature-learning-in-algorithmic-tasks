Please read the README.md in `code` directory before this.

`scaling_law_results`: Contains results of grid search for different tasks and input sizes

```
scaling_law_results/
├── [task]/
│   ├── 1/normal/11111/4/input_reverseTrue/output_reverseTrue/
│   │   ├── [input size]/individual_runs
│   │   │   └── [compute budget]
│   │   │   │   └── json files for each training run (logging paramters and training metrics)
```

Each json file contains:

```
{
    config: Training hyperparameters
    summary: Final Train loss, Final Val loss, Final Test Accuracy
}
```

`feature_probe_results`: Contains pickles for quiet / loud features across compute budgets. The pickle has format:

```
{
    [
        compute_budget (for ex, 10^9): {
            config_path: Corresponding language model training configuration (points to the json file from scaling_law_results) 
            compute_budget: 
            n_layer: Number of layers
            n_embd: Model dimension
            metrics: {
                feature_name: {
                    layer_idx: {
                        residual: {
                            train_acc, train_log_loss, test_acc, test_log_loss (for binary / multivalued features)
                            train_mse, train_r2, test_mse, test_r2 (for real valued features)
                        }
                    }
                }
            }
        }
        random_0 (Corresponding to feature probes trained on a random language model): {

        }
    ]
}
```